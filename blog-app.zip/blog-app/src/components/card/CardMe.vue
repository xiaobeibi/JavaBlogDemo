<template>
  <el-card>
    <h1 class="me-author-name">小贝比博客</h1>
    <div class="me-author-description">
      <span><i class="el-icon-location-outline"></i> &nbsp;浙江 & 杭州</span>
      <span
        ><i class="me-icon-job"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Java萌新</span
      >
    </div>
    <div class="me-author-tool">
      <i @click="showTool(qq)" :title="qq.title" class="iconfont icon-QQ"></i>
      <i
        @click="showTool(github)"
        :title="github.title"
        class="iconfont icon-GitHub"
      ></i>
      <i
        @click="showTool(gitee)"
        :title="gitee.title"
        class="iconfont icon-gitee"
      ></i>
      <i
        @click="showTool(blog)"
        :title="blog.title"
        class="iconfont icon-bokezhuanjia"
      ></i>
      <i
        @click="showTool(resume)"
        :title="resume.title"
        class="iconfont icon-jianli"
      ></i>
      <i
        @click="showTool(website)"
        :title="website.title"
        class="iconfont icon-a-wangzhanlianjiehulianwang"
      ></i>
    </div>
  </el-card>
</template>

<script>
export default {
  name: "CardMe",
  data() {
    return {
      qq: { title: "QQ", message: "814823564" },
      github: {
        title: "Github",
        message:
          '<a target="_blank" href="https://github.com/xiaobeibi">https://github.com/xiaobeibi</a>',
      },
      gitee: {
        title: "Gitee",
        message:
          '<a target="_blank" href="https://gitee.com/tytokongjian">https://gitee.com/tytokongjian</a>',
      },
      blog: {
        title: "笔记",
        message:
          '<a target="_blank" href="https://xiaobeibi.github.io/">https://xiaobeibi.github.io/</a>',
      },
      resume: {
        title: "简历",
        message:
          '<a target="_blank" href="https://tuyong.rth1.me/">https://tuyong.rth1.me/</a>',
      },
      website: {
        title: "个人网站",
        message:
          '<a target="_blank" href="https://obgeqwh.top">https://obgeqwh.top</a>',
      },
    };
  },
  methods: {
    showTool(tool) {
      this.$message({
        duration: 0,
        showClose: true,
        dangerouslyUseHTMLString: true,
        message: "<strong>" + tool.message + "</strong>",
      });
    },
  },
};
</script>

<style scoped>
.me-author-name {
  text-align: center;
  font-size: 30px;
  border-bottom: 1px solid #5fb878;
}

.me-author-description {
  padding: 8px 0;
}

.me-icon-job {
  padding-left: 16px;
}

.me-author-tool {
  text-align: center;
  padding-top: 10px;
}

.me-author-tool i {
  cursor: pointer;
  padding: 4px 10px;
  font-size: 30px;
}
</style>
